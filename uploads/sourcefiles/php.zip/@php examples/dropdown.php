<!DOCTYPE html>

<html>

<head>
  <title>example</title>
  <style type="text/css">
  body{
      color: white;
      font: Arial, Helvetica, sans-serif;
      background-color: black;
  }
  h1{
      color: red;
      background-color: yellow;
  }
  button{
      text-decoration: blink;
      font-weight: bold;
      font-style: italic;
  }
  option{
      align-items: center;
      }
  button:hover{
      color: white;
      background-color: #FF0000;
  }
  fieldset{
      align-content: center;
      width: 80px;
  }

  </style>
</head>

<body>

<h1>My quiz</h1>
<form action="dropdownReceive.php" method="post">
<fieldset>
    <label>What is your name</label>
<select name="Fname">
    <option>
        <option value="Collins">
            Collins Karani
        </option>
        <option value="Erick">
            Erick Machachari
        </option>
        <option value="Dan">
            Dan Situma
        </option>
        <option value="Alex">
            Alex Conn
        </option>
        </option>
</select>
<hr>

    <label>What is your age</label>
    <select name="age">
        <option>
            <option value="20">
                20 Years
            </option>
            <option value="21">
                21 Years
            </option>
            <option value="23">
                23 Years
            </option>
            <option value="25">
                25 Years
            </option>
        </option>
    </select>
    <hr>
    <label>Select Gender</label>
     <select name="gender">
    <option>
        <option value="M">
            Male
        </option>
        <option value="F">
            Female
        </option>
    </option>
     </select>
    <hr>
    <label>What is your town</label>
     <select name="town">
    <option>
        <option value="KK">
            Kakamega Town
        </option>
        <option value="Nrb">
            Nairobi City
        </option>
        <option value="Ksm">
            Kisumu City
        </option>
        <option value="Nkr">
            Nakuru Town
        </option>
        <option value="Eld">
            Eldoret Town
        </option>
    </option>
     </select>
    <hr>
    <label>Select Nationality</label>
     <select name="nationality">
    <option>
        <option value="Ug">
            Uganda
        </option>
        <option value="Tz">
            Tanzania
        </option>
        <option value="Kny">
            Kenya
        </option>
        <option value="Eth">
            Ethopia
        </option>
        <option value="Sd">
            Southern Sudan
        </option>
    </option>
     </select>
    <hr>
    <label>Select Tribe</label>
     <select name="tribe">
    <option>
        <option value="Lhy">
            Luhya
        </option>
        <option value="Kl">
            Kalenjin
        </option>
        <option value="Mr">
            Meru
        </option>
        <option value="kky">
            Kikuyu
        </option>
    </option>
     </select>
     <hr>
     <label>Comments</label>
     <textarea cols="50" rows="10">

     </textarea>
</fieldset>
<button type="submit" id="sub">
    Submit Details
</button>
<button type="reset">
    Reset/Refresh
</button>
</form>

</body>
</html>