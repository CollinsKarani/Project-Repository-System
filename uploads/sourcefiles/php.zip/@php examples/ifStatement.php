<!DOCTYPE html>

<html>

<head>
  <title>Hello!</title>
</head>

<body>

<?php
$d=date("D");
if($d=="Fri") echo "Have a blessed weekend!";
?>

</body>
</html>