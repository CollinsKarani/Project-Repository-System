<!DOCTYPE html>

<html>

<head>
  <title>whileLoop</title>
</head>

<body>

<?php
$i=1;
while($i<=10)
{
    echo "The number is: " .$i. "<br />" ;
    $i++;
}
 ?>
</body>
</html>