<!DOCTYPE html>

<html>

<head>
  <title>Get Time/Date php</title>
</head>

<body>
<h1>Getting date and time in php</h1>
<?php
print "<h2>Date: ";
print date("y-m-d");
print "</h2> \n";
print " <h2>Time: ";
print date("h:i:s");
print "</h2>";
?>

</body>
</html>