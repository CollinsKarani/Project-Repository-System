<!DOCTYPE html>

<html>

<head>
  <title>foreach</title>
</head>

<body>

<?php
 $x=array("one","two","three");
 foreach($x as $value)
 {
     echo  $value . "<br />";
 }
?>

</body>
</html>