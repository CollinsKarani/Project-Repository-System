<!DOCTYPE html>

<html>

<head>
  <title>interpolation</title>
</head>

<body>

<?php
$name="Collins Karani";
$address="254 Nairobi, Kenya";
$box="254, Nairobi";
$gender="Male";
$age="23 Years";
$profession="Computer Expert";
$nationality="Kenyan";
$output=" ";
$output="<table style=\"border: 1px solid black\">\n";
$output .="<tr> \n";
$output .="<td> Name</td>\n";
$output .="<td>$name</td>\n";
$output .="</tr>\n";
$output .="<tr>\n";
$output .="<td>Address</td>\n";
$output .="<td>$address</td>\n";
$output .="<tr> \n";
$output .="<tr>\n";
$output .="<td>BOX NO</td>\n";
$output .="<td>$box</td>\n";
$output .="<tr> \n";
$output .="<tr>\n";
$output .="<td>Gender</td>\n";
$output .="<td>$gender</td>\n";
$output .="<tr> \n";
$output .="<tr>\n";
$output .="<td>Age</td>\n";
$output .="<td>$age</td>\n";
$output .="<tr> \n";
$output .="<tr>\n";
$output .="<td>Profession</td>\n";
$output .="<td>$profession</td>\n";
$output .="<tr> \n";
$output .="<tr>\n";
$output .="<td>Nationality</td>\n";
$output .="<td>$nationality</td>\n";
$output .="<tr> \n";
$output .="</table> \n";
echo $output;
?>

</body>
</html>