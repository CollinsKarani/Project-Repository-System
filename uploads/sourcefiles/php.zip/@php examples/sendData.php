<!DOCTYPE html>

<html>

<head>
  <title>Hello!</title>
</head>

<body>
<form action="receiveData.php" method="post">
    <fieldset>
        <label>Please enter your full name</label>
        <input type="text"
        name="userName" />
        <button type="submit">
        Submit
        </button>
    </fieldset>
</form>
</body>
</html>