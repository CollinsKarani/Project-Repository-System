<!DOCTYPE html>

<html>

<head>
  <title>if_else_if_else</title>
</head>

<body>

<?php
$d=date("D");
if(date=="Fri")
echo "Have a blessed week";
else if(date=="Sun");
echo "Have a blessed Sunday";
else
echo "Have a blessed day";
?>

</body>
</html>