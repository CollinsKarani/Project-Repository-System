<!DOCTYPE html>

<html>

<head>
  <title>Heredoc</title>
</head>

<body>

<?php
$name="Collins Karani";
$address="2345-2000 000, Nairobi Kenya";
$box="254 Nairobi";
$gender="Male";
$age="24 Years";
$profession="IT expert";
$nationality="Kenyan";
echo <<<HERE
<table style="border: 1px solid black">
<tr>
<td>Name</td>
<td>$name</td>
</tr>
<tr>
<td>Address</td>
<td>$address</td>
</tr>
<td>BOX NO</td>
<td>$box</td>
<tr>
<tr>
<td>Gender</td>
<td>$gender</td>
<tr>
<tr>
<td>Age</td>
<td>$age</td>
<tr>
<tr>
<td>Profession</td>
<td>$profession</td>
<tr>
<tr>
<td>Nationality</td>
<td>$nationality</td>
<tr>
</table>
HERE;
?>

</body>
</html>