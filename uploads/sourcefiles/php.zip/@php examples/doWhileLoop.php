<!DOCTYPE html>

<html>

<head>
  <title>doWhileLoop</title>
</head>

<body>

<?php
$i=0;
do{
    $i++;
    echo "The number is: " .$i. "<br />";
}
while($i<=20);
?>

</body>
</html>