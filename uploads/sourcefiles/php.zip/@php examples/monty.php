<!DOCTYPE html>
<html lang = "en-US">
<head>
<meta charset = "UTF-8">
<title>monty.php</title>
<!-- Meant to run from monty.html -->
</head>
<body>
<h1>Monty Python quiz results</h1>
<?php
//gather the variables
$name = filter_input(INPUT_POST, "name");
$quest = filter_input(INPUT_POST, "quest");
//don't worry about check boxes yet; they may not exist
//send some output
$reply = <<< HERE
<p>
Your name is $name.
</p>
<p>
Your quest is $quest.
</p>
HERE;
print $reply;
//determine if she's a witch
$witch = false;
//See if check boxes exist
if (filter_has_var(INPUT_POST, "nose")){
$witch = true;
}
if (filter_has_var(INPUT_POST, "hat")){
$witch = true;
}
if (filter_has_var(INPUT_POST, "newt")){
$witch = true;
}
if ($witch == true){
print "<p>She's a witch!</p> \n";
} // end if
?>
</body>
</html>