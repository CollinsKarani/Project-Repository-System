<!DOCTYPE html>

<html>

<head>
  <title>ForLoop</title>
</head>

<body>

<?php
for($i=1;$i<=10;$i++)
{
 echo "The number is: " .$i. "<br />"; 
}
?>

</body>
</html>