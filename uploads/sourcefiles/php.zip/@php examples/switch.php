<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>switch.php</title>
</head>
<body>
<p>Ask the magic 8 ball a yes or no question!</p>
<?php
$yourNumber = rand(1,8);
switch($yourNumber){
case 1:
print "<p><img src=\"images/8ball1.png\" alt = \"fat chance\"
/></p>";
break;
case 2:
print "<p><img src=\"images/8ball2.png\" alt = \"Yes\" /></p> ";
break;
case 3:
print "<p><img src=\"images/8ball3.png\" alt = \"PhD\" /></p>";
break;
case 4:
print "<p><img src=\"images/8ball4.png\" alt = \"You didn't say
please\" /></p>";
break;
case 5:
print "<p><img src=\"images/8ball5.png\" alt = \"tell, then kill\"
/></p>";
break;
case 6:
print "<p><img src=\"images/8ball6.png\" alt = \"Why trust me?\"
/></p>";
break;
case 7:
print "<p><img src=\"images/8ball7.png\" alt = \"Ask your mother\"
/></p>";
break;
case 8:
print "<p><img src=\"images/8ball8.png\" alt = \"The answer is in
the question\" /></p>";
break;
default:
print "<p>An error has occurred. Please try again, or contact
support@somesite.com for assistance. Error code: 8BIC:$yourNumber
</p>";
}
?>
<p>
<a href="switch.php">Ask another question!</a>
</p>
</body>
</html>