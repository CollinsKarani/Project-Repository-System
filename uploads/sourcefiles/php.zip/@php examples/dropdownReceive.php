<!DOCTYPE html>

<html>

<head>
  <title>example</title>
</head>

<body>

<?php
$Fname=filter_input(INPUT_POST, "name");
$Age=filter_input(INPUT_POST, "age");
$Gender=filter_input(INPUT_POST, "gender");
$Town=filter_input(INPUT_POST, "town");
$Nationality=filter_input(INPUT_POST, "nationality");
$Tribe=filter_input(INPUT_POST, "tribe");
$Comments=filter_input(INPUT_POST, "comments");

$output=<<< HERE
<p>
Your name is $Fname.
</p>
<p>
Your age is $Age.
</p>
<p>
Your gender is $Gender.
</p>
<p>
Your town is $Town.
</p>
<p>
Your nationality is $Nationality.
</p>
<p>
Your tribe is $Tribe.
</p>
<p>
Comments: $Comments.
</p>
HERE;
echo $output;
?>
</body>
</html>