<!DOCTYPE html>

<html>

<head>
  <title>Hello!</title>
</head>

<body>

<?php
$userName=filter_input(INPUT_POST, "userName");
echo "<h1>Hi, $userName!</h1>";
?>

</body>
</html>